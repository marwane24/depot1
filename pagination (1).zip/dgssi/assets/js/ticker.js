// ticker
// var ticker = document.querySelector('.ticker')
//   , list = document.querySelector('.ticker__list')
//   , clone = list.cloneNode(true)

// ticker.append(clone)

const ticker = document.querySelector('.ticker');
if (ticker) {
  const list = document.querySelector('.ticker__list');
  if (list) {
    const clone = list.cloneNode(true);
    if (clone) {
      ticker.append(clone);
    }
  }
}
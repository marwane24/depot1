// (function($) {
//   Drupal.behaviors.myBehavior = {
//     attach: function (context, settings) { 
//       let items = document.querySelectorAll(".home-slider .carousel-item");
//       console.log('items', items)
//       items.forEach((el, index) => {
//         const minPerSlide = 1;
//         let next = el.nextElementSibling;
//         for (var i = 0; i < minPerSlide; i++) {
//           if (!next) {
//             // wrap carousel by using first child
//             next = items[0];
//           }
//           let cloneChild = next.cloneNode(true);
//           if (index === 0) {
//             el.classList.add("active");
//           }
//           el.appendChild(cloneChild.children[0]);
//           next = next.nextElementSibling;
//         }
//       });
//     }
//   }
  
// })(jQuery, Drupal);
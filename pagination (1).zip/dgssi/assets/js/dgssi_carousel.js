(function($, Drupal) {
  $( document ).ready(function() {
    $('.carousel').carousel({
      wrap: false,
      interval: 6000
    })
  });

  const firstHomeSliderElement = $( ".carousel-home-feature .carousel-item" ).first();
  if (firstHomeSliderElement.length) {
    firstHomeSliderElement.addClass('active')
  }
  let documents = document.querySelectorAll(".carousel-documents .carousel-item");
  if (documents.length > 0) {
    documents.forEach((el, index) => {
      const minPerSlide = 3;
      let next = el.nextElementSibling;
      for (var i = 1; i < minPerSlide; i++) {
        if (!next) {
          // wrap carousel by using first child
          next = documents[0];
        }
        let cloneChild = next.cloneNode(true);
        if (index === 0) {
          el.classList.add("active");
        }
        el.appendChild(cloneChild.children[0]);
        next = next.nextElementSibling;
      }
    });
  }

  let lois = document.querySelectorAll(".carousel-lois .carousel-item");
  if (lois.length > 0) {
    lois.forEach((el, index) => {
      const minPerSlide = 3;
      let next = el.nextElementSibling;
      for (var i = 1; i < minPerSlide; i++) {
        if (!next) {
          // wrap carousel by using first child
          next = lois[0];
        }
        let cloneChild = next.cloneNode(true);
        if (index === 0) {
          el.classList.add("active");
        }
        el.appendChild(cloneChild.children[0]);
        next = next.nextElementSibling;
      }
    });
  }

  Drupal.behaviors.dgssiCarousel = {
    attach: function (context, settings) { 
      $( document ).ready(function() {
        $('.carousel').carousel({
          wrap: false,
          interval: 6000
        })
      });
    
      let guides = document.querySelectorAll(".carousel-guides .carousel-item");
      if (guides.length > 0) {
        guides.forEach((el, index) => {
          const minPerSlide = 3;
          let next = el.nextElementSibling;
          for (var i = 1; i < minPerSlide; i++) {
            if (!next) {
              // wrap carousel by using first child
              next = guides[0];
            }
            let cloneChild = next.cloneNode(true);
            if (index === 0) {
              el.classList.add("active");
            }
            el.appendChild(cloneChild.children[0]);
            next = next.nextElementSibling;
          }
        });
      }
      
      // let decrets = document.querySelectorAll(".carousel-decrets .carousel-item");
      //   console.log('decrets', decrets);
      // if (decrets.length > 0) {
      //   decrets.forEach((el, index) => {
      //     const minPerSlide = 3;
      //     let next = el.nextElementSibling;
      //     for (var i = 1; i < minPerSlide; i++) {
      //       if (!next) {
      //         // wrap carousel by using first child
      //         next = decrets[0];
      //       }
      //       let cloneChild = next.cloneNode(true);
      //       if (index === 0) {
      //         el.classList.add("active");
      //       }
      //       el.appendChild(cloneChild.children[0]);
      //       next = next.nextElementSibling;
      //     }
      //   });
      // }

      // let circulaires = document.querySelectorAll(".carousel-circulaires .carousel-item");
      // if (circulaires.length > 0) {
      //   circulaires.forEach((el, index) => {
      //     const minPerSlide = 3;
      //     let next = el.nextElementSibling;
      //     for (var i = 1; i < minPerSlide; i++) {
      //       if (!next) {
      //         // wrap carousel by using first child
      //         next = circulaires[0];
      //       }
      //       let cloneChild = next.cloneNode(true);
      //       if (index === 0) {
      //         el.classList.add("active");
      //       }
      //       el.appendChild(cloneChild.children[0]);
      //       next = next.nextElementSibling;
      //     }
      //   });
      // }
    }
  }

})(jQuery, Drupal);
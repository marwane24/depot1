(function($, Drupal) {
  Drupal.behaviors.myBehavior = {
    attach: function (context, settings) { 
      $("a.organigrmpic").magnifik({ ratio: 7.5 });
      $("a.organigrmpicshema").magnifik({ ratio: 6.0 });
    }
  }

})(jQuery, Drupal);